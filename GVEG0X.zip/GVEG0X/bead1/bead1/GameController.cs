﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bead1
{
    class GameController
    {
        private Graph noice;

        public GameController()
        {
            int csomoPNumber = 0;
            int elekNumber = 0;
            string[] lines = File.ReadAllLines("input.txt");

            if (lines[0][2] == ' ')
            {
                csomoPNumber = (lines[0][0] - '0') * 10 + lines[0][1] - '0';

                if (lines[0].Length == 4)
                    elekNumber = lines[0][3] - '0';
                else
                    elekNumber = (lines[0][3] - '0') * 10 + lines[0][4] - '0';

            }
            else if (lines[0][1] == ' ')
            {
                csomoPNumber = lines[0][0] - '0';

                if (lines[0].Length == 3)
                    elekNumber = lines[0][2] - '0';
                else
                    elekNumber = (lines[0][2] - '0') * 10 + lines[0][3] - '0';
            }
            else
            {
                Console.WriteLine("Hiba c:");
                Console.ReadKey();
            }

            int[,] ordenareTomb = new int[elekNumber, 2];

            for (int i = 1; i < lines.Length; i++)
            {
                if (lines[i][2] == ' ')
                {
                    ordenareTomb[i - 1, 0] = (lines[i][0] - '0') * 10 + lines[i][1] - '0';

                    if (lines[i].Length == 4)
                        ordenareTomb[i - 1, 1] = lines[i][3] - '0';
                    else
                        ordenareTomb[i - 1, 1] = (lines[i][3] - '0') * 10 + lines[i][4] - '0';

                }
                else if (lines[i][1] == ' ')
                {
                    ordenareTomb[i - 1, 0] = lines[i][0] - '0';

                    if (lines[i].Length == 3)
                        ordenareTomb[i - 1, 1] = lines[i][2] - '0';
                    else
                        ordenareTomb[i - 1, 1] = (lines[i][2] - '0') * 10 + lines[i][3] - '0';
                }
            }

            noice = new Graph(elekNumber, csomoPNumber, ordenareTomb);

        }

        public void GameLogic()
        {
            int returnValue;

            if (noice.Elek == 1)
            {
                returnValue = 0;
            }
            else
            {
                returnValue = noice.dijkstra_GetMinDistances(0);

                for (int i = 1; i < noice.Vertecies; i++)
                {
                    if (returnValue > noice.dijkstra_GetMinDistances(i))
                        returnValue = noice.dijkstra_GetMinDistances(i);
                }
            }

            returnValue = -(returnValue - 1);
            Console.WriteLine(returnValue);


            using (StreamWriter outputFile = new StreamWriter("output.txt"))
            {
                outputFile.WriteLine(returnValue);
            }

        }
    }
}
