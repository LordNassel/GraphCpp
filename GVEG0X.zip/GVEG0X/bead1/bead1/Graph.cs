﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bead1
{
    class Graph
    {
        public int Vertecies { get; set; }
        public int Elek { get; set; }

        public int[,] CS;

        public Graph(int _elek, int _csucsok, int[,] cuccli)
        {
            Vertecies = _csucsok;
            Elek = _elek;

            CS = new int[Vertecies, Vertecies];
            
            for(int i = 0; i< Vertecies; i++)
            {
                for (int j = 0; j < Vertecies; j++)
                    CS[i, j] = 0;
            }

            for(int i=0; i<Elek; i++)
            {
                for(int j = 0; j<Vertecies;j++)
                {
                    if(cuccli[i,0] == j)
                    {
                        CS[j, cuccli[i, 1]] = 1;
                    }

                    if(cuccli[i,1] == j)
                    {
                        CS[j, cuccli[i, 0]] = 1;
                    }
                }
            }
        }

        //Megszerzi azt a vertexet aminek a legkissebb távolsága van ami még nincsen benne a Longest Path Tree-ben
        public int getMinimumVertex(bool[] mst, int[] key)
        {
            int minKey = int.MaxValue;
            int vertex = -1;
            for (int i = 0; i < Vertecies; i++)
            {
                if (!mst[i] && minKey > key[i])
                {
                    minKey = key[i];
                    vertex = i;
                }
            }
            return vertex;
        }

        public int dijkstra_GetMinDistances(int forrasVertex)
        {
            bool[] lpa = new bool[Vertecies];
            int[] distance = new int[Vertecies];
            int infinity = int.MaxValue;

            for (int i = 0; i < Vertecies; i++)
            {
                distance[i] = infinity;
            }

            distance[forrasVertex] = 0;
            int returnValue = 0;


            //Longest Path Algorythm kezdete
            for (int i = 0; i < Vertecies; i++)
            {
                int vertex_U = getMinimumVertex(lpa, distance);

                lpa[vertex_U] = true;

                for (int vertex_V = 0; vertex_V < Vertecies; vertex_V++)
                {
                    //megvizsgáljuk a távolságot
                    if (CS[vertex_U , vertex_V] > 0)
                    {

                        //megnézi hogy a Vertex_V benne van-e a Longest Path Tree-be
                        if (!lpa[vertex_V] && CS[vertex_U , vertex_V] != infinity)
                        {

                            //Megvizsgálja hogy update-elni kell a distance-t, az össz súly a forrástól a vertex_V-ig kisebb-e mint a mostani distance
                            //ha igen akkor update-eli a distance értékét, közben a legnagyobb távolságot is megkeresi
                            int newKey = -CS[vertex_U , vertex_V] + distance[vertex_U];

                            if (newKey < distance[vertex_V])
                            {
                                distance[vertex_V] = newKey;
                                if (distance[vertex_V] < returnValue)
                                    returnValue = distance[vertex_V];
                            }
                                
                        }
                    }
                }
            }

            return returnValue;
        }

    }
}
